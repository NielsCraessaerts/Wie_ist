package be.kdg.wieishet.Model;

public class Game {
    //public be.kdg.wieishet.Model.Speler speler1 = new be.kdg.wieishet.Model.Speler(label1.getText(), TeRadenPersoon.getInstance(),be.kdg.wieishet.Model.Spelbord spelbord1,Spelerskleur spelerskleur.Rood);
    //public be.kdg.wieishet.Model.Speler speler2 = new be.kdg.wieishet.Model.Speler(label2.getText(), TeRadenPersoon.getInstance(),be.kdg.wieishet.Model.Spelbord spelbord2,Spelerskleur spelerskleur.Blauw);
//    public int TotaalaantalBeurten;
    //public int SpeleraandeBeurt = TotaalaantalBeurten;

//    public static void showTurn(int TotaalaantalBeurten) {
//        if (TotaalaantalBeurten % 2 == 0) {
//            System.out.println("It is "+ Speler1.Naam +"'s turn");
//        } else {
//            System.out.println("It is "+ Speler2.Naam +"'s turn");
//        }
//    }

    //spelbord eventueel initialiserern in constructor vnan game klasse, niet in speler. SPELER zelf ook instantieren in constructor


}
