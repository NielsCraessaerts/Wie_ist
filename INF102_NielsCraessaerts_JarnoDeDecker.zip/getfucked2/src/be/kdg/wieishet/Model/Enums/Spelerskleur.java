package be.kdg.wieishet.Model.Enums;

public enum Spelerskleur {
    Rood,Blauw;
}
