package be.kdg.wieishet.Model.Enums;

public enum Toestand {
    Open, Toe;


}
