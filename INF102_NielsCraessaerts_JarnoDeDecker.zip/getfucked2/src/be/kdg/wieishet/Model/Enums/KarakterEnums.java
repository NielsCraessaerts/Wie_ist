package be.kdg.wieishet.Model.Enums;

public enum KarakterEnums {

}
